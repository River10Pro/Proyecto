<?php
include "conexion.php"; // Aquí tienes la conexión MongoDB y la variable $db

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST["nombre"]);
    $apellido = trim($_POST["apellido"]);
    $telefono = trim($_POST["telefono"]);
    $email = trim($_POST["email"]);
    $direccion = trim($_POST["direccion"]);

    // Validaciones básicas
    if (empty($nombre) || empty($apellido) || empty($telefono) || empty($email)) {
        echo "Error: Todos los campos obligatorios deben estar completos.";
        exit;
    }

    if (!preg_match("/^\d{10}$/", $telefono)) {
        echo "Error: El número de teléfono debe tener exactamente 10 dígitos.";
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Error: El formato del correo electrónico no es válido.";
        exit;
    }

    $coleccion = $db->selectCollection('contactos');

    // Verificar si teléfono o email ya existen
    $existe = $coleccion->findOne([
        '$or' => [
            ['telefono' => $telefono],
            ['email' => $email]
        ]
    ]);

    if ($existe) {
        if ($existe['telefono'] === $telefono) {
            echo "Error: El número de teléfono ya está registrado.";
            exit;
        }
        if ($existe['email'] === $email) {
            echo "Error: El correo electrónico ya está registrado.";
            exit;
        }
    }

    // Insertar nuevo contacto
    $nuevoContacto = [
        'nombre' => $nombre,
        'apellido' => $apellido,
        'telefono' => $telefono,
        'email' => $email,
        'direccion' => $direccion
    ];

    $resultado = $coleccion->insertOne($nuevoContacto);

    if ($resultado->getInsertedCount() == 1) {
        echo "¡Contacto guardado exitosamente!";
    } else {
        echo "Error al guardar el contacto.";
    }
}
