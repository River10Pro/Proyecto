<?php
include "conexion.php"; // Este debe tener la conexión MongoDB y $db definida

use MongoDB\BSON\ObjectId;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir datos del formulario
    $id = $_POST["id"];
    $nombre = $_POST["nombre"];
    $apellido = $_POST["apellido"];
    $telefono = $_POST["telefono"];
    $email = $_POST["email"];
    $direccion = $_POST["direccion"];

    // Seleccionamos la colección
    $coleccion = $db->selectCollection('contactos');

    // Creamos filtro por _id (MongoDB usa ObjectId)
    $filtro = ['_id' => new ObjectId($id)];

    // Datos para actualizar
    $datosActualizar = [
        '$set' => [
            'nombre' => $nombre,
            'apellido' => $apellido,
            'telefono' => $telefono,
            'email' => $email,
            'direccion' => $direccion
        ]
    ];

    // Ejecutar actualización
    $resultado = $coleccion->updateOne($filtro, $datosActualizar);

    if ($resultado->getModifiedCount() > 0) {
        echo "¡Contacto actualizado correctamente!";
    } else {
        echo "No se realizaron cambios o el contacto no existe.";
    }
}
?>
