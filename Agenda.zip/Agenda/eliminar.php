<?php
include "conexion.php";

use MongoDB\BSON\ObjectId;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $coleccion = $db->selectCollection('contactos');

    $resultado = $coleccion->deleteOne(['_id' => new ObjectId($id)]);

    if ($resultado->getDeletedCount() == 1) {
        echo "¡Contacto eliminado correctamente!";
    } else {
        echo "Error al eliminar el contacto.";
    }
}
?>
