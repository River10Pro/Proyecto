<?php
include "conexion.php";

$coleccion = $db->selectCollection('contactos');

// Obtener todos los documentos ordenados por _id descendente (MongoDB no tiene campo id autoincremental)
$documentos = $coleccion->find([], ['sort' => ['_id' => -1]]);

$hayContactos = false;

foreach ($documentos as $row) {
    $hayContactos = true;

    echo '<div class="card contact-card mb-3 p-3" style="background-color: #2a2a2a; color: white;">';

    // Información del contacto
    echo '<div>';
    echo '<strong>' . htmlspecialchars($row["nombre"]) . ' ' . htmlspecialchars($row["apellido"]) . '</strong><br>';
    echo '<i class="fa fa-phone"></i> ' . htmlspecialchars($row["telefono"]) . '<br>';
    echo '<i class="fa fa-envelope"></i> ' . htmlspecialchars($row["email"]) . '<br>';
    echo '<i class="fa fa-map-marker-alt"></i> ' . htmlspecialchars($row["direccion"]) . '<br>';
    echo '</div>';

    // Botones Editar y Eliminar con data-id MongoDB (_id es un objeto, lo convertimos a string)
    $idStr = (string)$row['_id'];

    echo '<div class="mt-3 text-end">';
    echo '<button class="btn btn-sm btn-warning editar me-2" data-id="' . $idStr . '" 
            data-nombre="' . htmlspecialchars($row["nombre"]) . '" 
            data-apellido="' . htmlspecialchars($row["apellido"]) . '" 
            data-telefono="' . htmlspecialchars($row["telefono"]) . '" 
            data-email="' . htmlspecialchars($row["email"]) . '" 
            data-direccion="' . htmlspecialchars($row["direccion"]) . '">
            <i class="fa fa-edit"></i> Editar
          </button>';
    echo '<button class="btn btn-sm btn-danger eliminar" data-id="' . $idStr . '">
            <i class="fa fa-trash"></i> Eliminar
          </button>';
    echo '</div>';

    echo '</div>';
}

if (!$hayContactos) {
    echo "<p>No hay contactos guardados aún.</p>";
}
?>
