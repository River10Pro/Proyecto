<?php
// Activa la visualización de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'vendor/autoload.php';  // Carga la librería MongoDB

use MongoDB\Client;

try {
    // Crear cliente MongoDB (conexión al servidor local)
    $client = new Client("mongodb://localhost:27017");

    // Seleccionar base de datos 'agenda'
    $db = $client->selectDatabase('agenda');

    echo "¡Conexión a MongoDB exitosa!";
} catch (Exception $e) {
    die("Error de conexión a MongoDB: " . $e->getMessage());
}
